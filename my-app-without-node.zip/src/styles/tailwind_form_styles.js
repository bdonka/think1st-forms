const formStyles = {
  container: "bg-[#EDE6F5] min-h-screen flex flex-col items-center py-10",
  form: "w-full max-w-lg p-8",
  heading: "text-2xl font-semibold text-[#1F1B3C] mb-6",
  fieldContainer: "mb-4",
  label: "block text-sm font-medium text-[#1F1B3C]",
  input: "mt-1 w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-[#8A4FFF] focus:outline-none",
  inputCalendar: "appearance-none w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#8A4FFF] focus:outline-none text-gray-700 bg-white shadow-sm cursor-pointer [&::-webkit-calendar-picker-indicator]:opacity-0 [&::-webkit-datetime-edit]:pr-2",
  inputError: "border-red-500 text-red-600 focus:ring-red-500",
  button: "w-full mt-4 px-4 py-2 bg-[#8A4FFF] text-white font-semibold rounded-md hover:bg-[#6F3FFF] disabled:bg-[#D1C4E9]",
  uploadContainer: "flex flex-col items-center justify-center p-4 border-2 border-dashed rounded-md cursor-pointer bg-[#F1F5F8] hover:border-[#8A4FFF] break-all",
  selectedTime: "px-3 py-1 rounded-md bg-[#8A4FFF] text-white",
  timeContainer: "flex flex-col md:flex-row gap-4 items-start",
  hour: "bg-[#8A4FFF] text-white border-[#8A4FFF]",
  hourButton: "mb-2 mr-2 px-4 py-2 border rounded-md",
  selectedHour: "bg-white border-gray-300 hover:border-[#8A4FFF]",
  calendarContainer: "w-full max-w-sm mx-auto",
  calendar: "bg-white rounded-lg shadow-md p-2 border border-gray-300",
  calendarTile: "text-[#1F1B3C] hover:bg-[#EDE6F5] rounded-md p-2",


  rangeWrapper: "flex items-center relative w-full pt-8 pb-8 rounded-lg",
  rangeMinLimit: "text-sm font-bold text-[#1a1a50] absolute top-1 left-1",
  rangeMaxLimit: "text-sm font-bold text-[#1a1a50] absolute top-1 right-0",
  rangeInput: `
flex-1 appearance-none h-1.5 bg-purple-300 rounded-md outline-none transition duration-300
      [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4
      [&::-webkit-slider-thumb]:bg-purple-700 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:cursor-pointer
      [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:bg-purple-700 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:cursor-pointer
  `,
  valueIndicator: `
absolute top-[45px] bg-white text-purple-700 font-bold px-2 py-1 rounded-md text-sm border border-purple-300 -translate-x-2
  `,
  valueTriangle: `
   absolute top-[-10%] left-1/2 transform -translate-x-1/2 w-0 h-0
  border-l-4 border-l-transparent border-r-4 border-r-transparent border-b-4 border-b-white
  `,
  checkbox: "w-4 h-4 sm:w-5 sm:h-5",

  validationMessage: "text-sm text-red-500 mt-1",
  // validationMessage: "relative text-sm text-red-500 mt-1 before:content-['!'] before:absolute before:-left-6 before:w-4 before:h-4 before:rounded-full before:border before:border-red-500 before:flex before:items-center before:justify-center before:text-xs before:font-bold before:bg-red-500 before:text-white",

  mobileNone: "hidden sm:block",
};

export default formStyles;