import { ChangeEvent, Dispatch, SetStateAction, useEffect, useState, DragEvent, useRef } from "react";
import { fetchHolidays } from "./common/services/holidays";
import { Field, FormPayload, Holiday } from "./common/types";
import { saveForm } from "./common/services/form";
import { emailValidator } from "./common/validators";
import formStyles from "./styles/tailwind_form_styles";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";

const RequiredFieldContainer = ({ value, dirty }: Field) => {
  return dirty && !String(value).length ? <div>Field is required</div> : null;
};

const ValidatorFieldContainer = ({ value, dirty, validators }: Field) => {
  const validatorsMessages = validators.flatMap((validator) => validator(value));
  return dirty && String(value).length && validatorsMessages.length ? <div>{validatorsMessages.map((message, index) => <p key={index}>{message}</p>)}</div> : null;
};

const App = () => {
  const [firstname, setFirstname] = useState<Field>({ value: "", dirty: false, validators: [] });
  const [surname, setSurname] = useState<Field>({ value: "", dirty: false, validators: [] });
  const [email, setEmail] = useState<Field>({ value: "", dirty: false, validators: [emailValidator] });
  const [age, setAge] = useState<Field>({ value: 8, dirty: false, validators: [] });
  const [attachment, setAttachment] = useState<Field>({ value: "", dirty: false, validators: [] });
  const [date, setDate] = useState<Field>({ value: "", dirty: false, validators: [] });
  const [selectedTime, setSelectedTime] = useState<Field>({ value: "", dirty: false, validators: [] });
  
  const sliderRef = useRef<HTMLInputElement | null>(null);
  const [thumbPosition, setThumbPosition] = useState(0);

  const availableTimes = ["12:00", "14:00", "16:30", "18:30", "20:00"];

  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [holiday, setHoliday] = useState<Holiday | null>(null)

  const getRelatedHolidaysObject = () => holidays.find((holiday) => holiday.date === date.value);

  const isObservanceHoliday = () => holiday?.type === "OBSERVANCE";

  const isNationalHolidays = () => holiday?.type === "NATIONAL_HOLIDAY";

  const isEveryFieldRequired = () => {
    const formFields = [firstname, surname, email, age, attachment, date, selectedTime];
    return formFields.every((field) =>
      String(field.value).length > 0 && (field.validators as Array<Function>).every((validator) => validator(String(field.value)).length === 0)
    );
  };

  const isDisabledForm = () => isNationalHolidays() || !isEveryFieldRequired();

  useEffect(() => {
    if (sliderRef.current) {
      const slider = sliderRef.current;
      const sliderWidth = slider.clientWidth;
      
      const min = Number(slider.min);
      const max = Number(slider.max);
      const newPosition = ((+age.value - min) / (max - min)) * (sliderWidth - 20);

      setThumbPosition(newPosition);
    }
  }, [age.value]);

  const onChangeHandler = (event: ChangeEvent<HTMLInputElement>, callback: Dispatch<SetStateAction<any>>) => {
    callback((prev: Field) => ({ ...prev, value: event.target.value }));
  };

  const onBlurHandler = (callback: Dispatch<SetStateAction<any>>) => {
    callback((prev: Field) => ({ ...prev, dirty: true }));
  };



  const onDrop = (event: DragEvent<HTMLDivElement>, callback: Dispatch<SetStateAction<any>>) => {
    event.preventDefault();
    if (event.dataTransfer?.items) {
      const files = [...event.dataTransfer.items].reduce((acc, item) => {
        if (item.kind === "file") {
          const file = item.getAsFile();
          if (file) {
            acc.push(file);
          }
        }
        return acc;
      }, [] as File[]);
      callback((prev: Field) => ({ ...prev, value: files[0].name }));
    } else {
      callback((prev: Field) => ({ ...prev, value: "" }));
    }
  };

  const onDragOver = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  const onClickElement = (id: string) => {
    document.getElementById(id)?.click();
  };

  const fetchHolidaysEffect = async () => {
    try {
      const { data } = await fetchHolidays("PL", 2024);
      setHolidays(data);
    } catch (_) {
      setHolidays([]);
    }
  };

  useEffect(() => {
    fetchHolidaysEffect();
  }, []);

  const handleObservanceHolidayDate = () => {
    const holidaysRelatedObject = getRelatedHolidaysObject();
    setHoliday(holidaysRelatedObject ?? null);
  };

  useEffect(() => {
    handleObservanceHolidayDate();
  }, [date]);

  const onSendHandler = async () => {
    const payload = { firstname: firstname.value, surname: surname.value, email: email.value, age: age.value, attachment: attachment.value, date: date.value, selectedTime: selectedTime.value };
    try {
      await saveForm(payload as FormPayload);
    } catch (error) {
      console.error("Exception", error);
    }
  };

return (
  <div className={formStyles.container}>
    <div className={formStyles.form}>
      <h2 className={formStyles.heading}>Personal info</h2>

      <div className={formStyles.fieldContainer}>
        <label className={formStyles.label}>First Name</label>
        <input 
          className={formStyles.input} 
          value={firstname.value} 
          onChange={(event) => onChangeHandler(event, setFirstname)} 
          onBlur={() => onBlurHandler(setFirstname)} 
        />
        <div className={formStyles.validationMessage}>
          <RequiredFieldContainer {...firstname} />
          <ValidatorFieldContainer {...firstname} />
        </div>
      </div>

      <div className={formStyles.fieldContainer}>
        <label className={formStyles.label}>Last Name</label>
        <input 
          className={formStyles.input} 
          value={surname.value} 
          onChange={(event) => onChangeHandler(event, setSurname)} 
          onBlur={() => onBlurHandler(setSurname)} 
        />
        <div className={formStyles.validationMessage}>
          <RequiredFieldContainer {...surname} />
          <ValidatorFieldContainer {...surname} />
        </div>
      </div>

      <div className={formStyles.fieldContainer}>
        <label className={formStyles.label}>Email Address</label>
        <input 
          className={formStyles.input} 
          value={email.value} 
          onChange={(event) => onChangeHandler(event, setEmail)} 
          onBlur={() => onBlurHandler(setEmail)} 
        />
        <div className={formStyles.validationMessage}>
          <RequiredFieldContainer {...email} />
          <ValidatorFieldContainer {...email} />
        </div>
      </div>

      <div className={formStyles.fieldContainer}>
        <label className={formStyles.label}>Age</label>
        <div className={formStyles.rangeWrapper}>
          <span className={formStyles.rangeMinLimit}>8</span>

          <input
            ref={sliderRef}
            className={`${formStyles.rangeInput}`}
            value={+age.value}
            type="range"
            min={8}
            max={100}
            step={1}
            onChange={(event) => onChangeHandler(event, setAge)}
            onBlur={() => onBlurHandler(setAge)}
          />

          <div
            className={formStyles.valueIndicator}
            style={{ left: `${thumbPosition}px` }}
          >
            {age.value}
            <div className={formStyles.valueTriangle}></div>
          </div>

          <span className={formStyles.rangeMaxLimit}>100</span>
        </div>
        <div className={formStyles.validationMessage}>
          <RequiredFieldContainer {...age} />
          <ValidatorFieldContainer {...age} />
        </div>
      </div>

      <div className={formStyles.fieldContainer}>
        <label className={formStyles.label}>Photo</label>
        <div
          className={formStyles.uploadContainer}
          tabIndex={0}
          onDrop={(event) => onDrop(event, setAttachment)}
          onDragOver={(event) => onDragOver(event)}
          onClick={() => onClickElement("attachment")}
        >
          {!attachment.value && (
            <>
              <u>Upload a file</u><p className={formStyles.mobileNone}>or drag and drop here</p>
              {attachment.value}
            </>
          )}
          {attachment.value && <span>{attachment.value}</span>}
          <input 
            id="attachment" 
            className="hidden" 
            type="file" 
            onChange={(event) => onChangeHandler(event, setAttachment)} 
            onBlur={() => onBlurHandler(setAttachment)} 
          />
        </div>
        <div className={formStyles.validationMessage}>
          <RequiredFieldContainer {...attachment} />
          <ValidatorFieldContainer {...attachment} />
        </div>
      </div>

      <h2 className={formStyles.heading}>Your workout</h2>

      <div className={formStyles.timeContainer}>
        <div className={formStyles.fieldContainer}>
          <label className={formStyles.label}>Date</label>
          <div className={formStyles.calendarContainer}></div>
              <Calendar
                onChange={(value) => {
                  if (value instanceof Date) {
                    setDate({ ...date, value: value.toLocaleDateString("sv-SE") });
                  }
                }}
                value={date.value ? new Date(date.value) : null}
                className={formStyles.calendar}
                tileClassName={formStyles.calendarTile}
                nextLabel="▶"
                prevLabel="◀"
              />
          <div className={formStyles.validationMessage}>
            <RequiredFieldContainer {...date} />
            <ValidatorFieldContainer {...date} />
          </div>
        </div>
        {!isObservanceHoliday() && (
          <div className={formStyles.fieldContainer}>
            <label className={formStyles.label}>Time</label>
            <div className={formStyles.hoursContainer}>
                {availableTimes.map((time) => (
                <button
                  key={time}
                  className={`${formStyles.hourButton} ${
                    selectedTime.value === time
                      ? formStyles.hour
                      : formStyles.selectedHour
                  }`}
                  onClick={() => setSelectedTime((prev) => ({ ...prev, value: time }))}
                >
                  {time}
                </button>
                ))}
            </div>
            <div className={formStyles.validationMessage}>
              <RequiredFieldContainer {...selectedTime} />
              <ValidatorFieldContainer {...selectedTime} />
            </div>
          </div>
        )}
      </div>

      <div className={formStyles.fieldContainer}>
        {isObservanceHoliday() && (
          <div className={formStyles.selectedTime}>
            {holiday?.name}
          </div>
        )}
      </div>

      <div className={formStyles.fieldContainer}>
        <button 
          type="button" 
          disabled={isDisabledForm()} 
          onClick={() => onSendHandler()} 
          className={formStyles.button}
        >
          Send Application
        </button>
      </div>
    </div>
  </div>
);
}

export default App;
